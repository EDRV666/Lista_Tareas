const { Task } = require('../models');

exports.getAllTasks = async (req, res) => {
  try {
    const tasks = await Task.findAll({ where: { userId: req.session.userId } });
    res.status(200).send(tasks);
  } catch (error) {
    res.status(500).send({ message: 'Error getting tasks' });
  }
};

exports.createTask = async (req, res) => {
  try {
    const { title, description } = req.body;
    const task = await Task.create({ title, description, userId: req.session.userId });
    res.status(201).send({ message: 'Task created successfully' });
  } catch (error) {
    res.status(500).send({ message: 'Error creating task' });
  }
};

exports.updateTask = async (req, res) => {
  try {
    const { id, title, description } = req.body;
    const task = await Task.update({ title, description }, { where: { id, userId: req.session.userId } });
    res.status(200).send({ message: 'Task updated successfully' });
  } catch (error) {
    res.status(500).send({ message: 'Error updating task' });
  }
};

exports.deleteTask = async (req, res) => {
  try {
    const { id } = req.body;
    await Task.destroy({ where: { id, userId: req.session.userId } });
    res.status(200).send({ message: 'Task deleted successfully' });
  } catch (error) {
    res.status(500).send({ message: 'Error deleting task' });
  }
};