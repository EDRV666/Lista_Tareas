const { User } = require('../models');
const bcrypt = require('bcrypt');

exports.register = async (req, res) => {
  try {
    const { username, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({ username, password: hashedPassword });
    res.status(201).send({ message: 'User  created successfully' });
  } catch (error) {
    res.status(500).send({ message: 'Error creating user' });
  }
};

exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ where: { username } });
    if (!user) {
      res.status(401).send({ message: 'Invalid username or password' });
    } else {
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        res.status(401).send({ message: 'Invalid username or password' });
      } else {
        req.session.userId = user.id;
        res.status(200).send({ message: 'Logged in successfully' });
      }
    }
  } catch (error) {
    res.status(500).send({ message: 'Error logging in' });
  }
};