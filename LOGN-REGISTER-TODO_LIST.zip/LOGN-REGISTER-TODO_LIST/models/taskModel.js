const mysql = require('mysql2/promise');

const db = mysql.createPool({
  host: 'tu_host',
  user: 'tu_usuario',
  password: 'tu_contraseña',
  database: 'tu_base_de_datos'
});