module.exports =  {
    host:  'localhost',
    user: 'root',
    password: '040504EDGAR',
    database: 'crud_tasks',
};