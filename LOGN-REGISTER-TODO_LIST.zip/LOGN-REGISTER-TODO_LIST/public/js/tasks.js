const taskList = document.getElementById('task-list');

async function getTasks() {
  try {
    const response = await fetch('/api/tasks', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });
    const tasks = await response.json();
    taskList.innerHTML = '';
    tasks.forEach((task) => {
      const taskElement = document.createElement('li');
      taskElement.textContent = task.title;
      taskList.appendChild(taskElement);
    });
  } catch (error) {
    console.error(error);
  }
}

getTasks();

const createTaskForm = document.getElementById('create-task-form');

createTaskForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const title = document.getElementById('title').value;
  const description = document.getElementById('description').value;
  try {
    const response = await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, description })
    });
    const data = await response.json();
    if (data.message === 'Task created successfully') {
      getTasks();
    } else {
      alert('Error creating task');
    }
  } catch (error) {
    console.error(error);
  }
});